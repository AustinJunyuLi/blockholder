"""
Systematic recalibration sweep for the EVT model.

Explores (lambda_B, C0, S_bar, s_xi) space to find parameters that produce:
1. Interior hump in Delta^min (peak at kappa in [0.25, 0.70])
2. Hold region exists (k0 > k1 + 0.01)
3. Disclosure effect (baseline != no-disclosure)
4. Realistic bid rates (unconditional ~2-8%)
5. Hump amplitude > 5% of peak value
"""

import itertools
import warnings
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np

from numerical.params import ModelParams, Cutoffs
from numerical.solver import solve_equilibrium, equilibrium_residual
from numerical.model import (
    compute_action_probabilities,
    compute_equilibrium_prices,
    compute_minority_gains,
    compute_minority_gains_no_disclosure_given_strategy,
    bid_probability,
    noise_probs,
)

warnings.filterwarnings("ignore")


@dataclass
class CalibrationResult:
    """Diagnostics for a single parameter configuration."""
    lambda_B: float
    C0: float
    S_bar: float
    s_xi: float
    Delta_S: float

    # Hump diagnostics
    hump_exists: bool
    hump_peak_kappa: float
    hump_peak_value: float
    hump_amplitude_pct: float  # (peak - min) / peak * 100

    # Hold region
    hold_exists: bool
    hold_width_at_050: float  # k0 - k1 at kappa=0.50

    # Disclosure effect
    disclosure_effect_pct: float  # (act - act_nd) / act * 100 at kappa=0.50

    # Bid rates
    max_bid_rate: float
    avg_bid_rate: float

    # Solver quality
    max_residual: float
    n_failed: int

    # Net deterrence
    net_deterrence: bool

    # Overall score (higher = better)
    score: float = 0.0


def evaluate_calibration(
    lambda_B: float, C0: float, S_bar: float, s_xi: float, Delta_S: float,
    kappa_grid: np.ndarray,
) -> Optional[CalibrationResult]:
    """Run a quick kappa sweep and evaluate calibration quality."""

    params_base = ModelParams(
        lambda_B=lambda_B, C0=C0, S_bar=S_bar, s_xi=s_xi, Delta_S=Delta_S
    )

    # Check net deterrence condition
    if not params_base.net_deterrence_active:
        return None

    k1_vals, k0_vals, kD_vals = [], [], []
    Delta_min_vals = []
    act_vals, act_nd_vals = [], []
    bid_rates = []
    residuals = []
    n_failed = 0
    prev = None

    for kappa in kappa_grid:
        try:
            p = params_base.replace(kappa=float(kappa))

            if prev is not None:
                cut = solve_equilibrium(p, k1_init=prev.k1, k0_init=prev.k0, kD_init=prev.kD, max_iter=80)
            else:
                cut = solve_equilibrium(p, max_iter=80)

            res = equilibrium_residual(cut.k1, cut.k0, cut.kD, p)
            residuals.append(res)

            if res > 0.05:
                n_failed += 1
                k1_vals.append(np.nan)
                k0_vals.append(np.nan)
                kD_vals.append(np.nan)
                Delta_min_vals.append(np.nan)
                act_vals.append(np.nan)
                act_nd_vals.append(np.nan)
                bid_rates.append(np.nan)
                continue

            prev = cut
            k1_vals.append(cut.k1)
            k0_vals.append(cut.k0)
            kD_vals.append(cut.kD)

            mg = compute_minority_gains(cut.k1, cut.k0, cut.kD, p)
            mg_nd = compute_minority_gains_no_disclosure_given_strategy(cut.k1, cut.k0, cut.kD, p)

            Delta_min_vals.append(mg.total)
            act_vals.append(mg.activism)
            act_nd_vals.append(mg_nd.activism)

            # Compute avg bid rate
            prices, E_v_dict = compute_equilibrium_prices(cut.k1, cut.k0, cut.kD, p)
            posteriors_dict = {}
            omega_E, omega_H, omega_Q, omega_P = compute_action_probabilities(cut.k1, cut.k0, cut.kD, p)
            from numerical.model import compute_posteriors
            posteriors_dict = compute_posteriors(omega_E, omega_H, omega_Q, omega_P, p.kappa)

            p0, p1 = noise_probs(p.kappa)
            avg_p_bid = 0.0
            for (X, D), price in prices.items():
                pi = posteriors_dict.get((X, D), 0.0)
                E_v = E_v_dict.get((X, D), p.mu)
                V_hat = E_v + p.Delta_tilde * pi
                m_XD = p.m0 + (p.m_tilde - p.m0) * pi
                pb = p.lambda_B * bid_probability(V_hat, m_XD, pi, p)
                avg_p_bid = max(avg_p_bid, pb)
            bid_rates.append(avg_p_bid)

        except Exception:
            n_failed += 1
            for lst in (k1_vals, k0_vals, kD_vals, Delta_min_vals, act_vals, act_nd_vals, bid_rates):
                lst.append(np.nan)

    # Convert to arrays
    k1_arr = np.array(k1_vals)
    k0_arr = np.array(k0_vals)
    kD_arr = np.array(kD_vals)
    dm_arr = np.array(Delta_min_vals)
    act_arr = np.array(act_vals)
    act_nd_arr = np.array(act_nd_vals)
    bid_arr = np.array(bid_rates)

    valid = ~np.isnan(dm_arr)
    if valid.sum() < 5:
        return None

    # Hump diagnostics
    dm_valid = dm_arr[valid]
    kappa_valid = kappa_grid[valid]

    peak_idx = np.argmax(dm_valid)
    peak_kappa = kappa_valid[peak_idx]
    peak_value = dm_valid[peak_idx]
    min_value = np.min(dm_valid)

    # Hump exists if peak is interior (not at boundary)
    hump_exists = (peak_idx > 0) and (peak_idx < len(dm_valid) - 1)
    hump_amplitude = (peak_value - min_value) / peak_value * 100 if peak_value > 1e-10 else 0.0

    # Hold region at kappa=0.50
    idx_050 = np.argmin(np.abs(kappa_grid - 0.50))
    hold_width = k0_arr[idx_050] - k1_arr[idx_050] if not np.isnan(k0_arr[idx_050]) else 0.0
    hold_exists = hold_width > 0.01

    # Disclosure effect at kappa=0.50
    if not np.isnan(act_arr[idx_050]) and act_arr[idx_050] > 1e-10:
        disc_effect = (act_arr[idx_050] - act_nd_arr[idx_050]) / act_arr[idx_050] * 100
    else:
        disc_effect = 0.0

    # Bid rates
    bid_valid = bid_arr[valid]
    max_bid = np.nanmax(bid_valid) if len(bid_valid) > 0 else 0.0
    avg_bid = np.nanmean(bid_valid) if len(bid_valid) > 0 else 0.0

    max_res = max(residuals) if residuals else 999.0

    result = CalibrationResult(
        lambda_B=lambda_B, C0=C0, S_bar=S_bar, s_xi=s_xi, Delta_S=Delta_S,
        hump_exists=hump_exists,
        hump_peak_kappa=float(peak_kappa),
        hump_peak_value=float(peak_value),
        hump_amplitude_pct=float(hump_amplitude),
        hold_exists=hold_exists,
        hold_width_at_050=float(hold_width),
        disclosure_effect_pct=float(disc_effect),
        max_bid_rate=float(max_bid),
        avg_bid_rate=float(avg_bid),
        max_residual=float(max_res),
        n_failed=n_failed,
        net_deterrence=params_base.net_deterrence_active,
    )

    # Score the configuration
    score = 0.0

    # Hump (most important)
    if hump_exists:
        score += 30.0
        # Bonus for peak in [0.30, 0.65]
        if 0.30 <= peak_kappa <= 0.65:
            score += 15.0
        # Bonus for amplitude
        score += min(hump_amplitude, 20.0)

    # Hold region
    if hold_exists:
        score += 15.0
        score += min(hold_width * 10, 5.0)

    # Disclosure effect
    if abs(disc_effect) > 1.0:
        score += 10.0
        score += min(abs(disc_effect) / 5, 5.0)

    # Bid rates in [0.02, 0.10]
    if 0.02 <= avg_bid <= 0.10:
        score += 10.0
    elif 0.01 <= avg_bid <= 0.15:
        score += 5.0

    # Penalty for solver failures
    score -= n_failed * 5.0

    # Penalty for extreme residuals
    if max_res > 0.01:
        score -= 10.0

    result.score = score
    return result


def main():
    # Coarse grid for initial sweep
    kappa_grid = np.linspace(0.15, 0.85, 15)

    # Parameter grid
    lambda_B_grid = [0.10, 0.15, 0.20, 0.30]
    C0_grid = [0.15, 0.20, 0.25, 0.30, 0.40]
    S_bar_grid = [0.60, 0.80, 1.00, 1.20]
    s_xi_grid = [0.10, 0.15, 0.20, 0.30]
    Delta_S_grid = [0.20, 0.35]

    total = len(lambda_B_grid) * len(C0_grid) * len(S_bar_grid) * len(s_xi_grid) * len(Delta_S_grid)
    print(f"Sweeping {total} parameter combinations over {len(kappa_grid)} kappa values...")

    results: List[CalibrationResult] = []
    count = 0

    for lB, c0, sb, sx, ds in itertools.product(
        lambda_B_grid, C0_grid, S_bar_grid, s_xi_grid, Delta_S_grid
    ):
        count += 1
        if count % 50 == 0:
            print(f"  [{count}/{total}]")

        r = evaluate_calibration(lB, c0, sb, sx, ds, kappa_grid)
        if r is not None:
            results.append(r)

    print(f"\n{len(results)} valid configurations evaluated.")

    # Sort by score
    results.sort(key=lambda r: r.score, reverse=True)

    # Print top 20
    print("\n" + "=" * 120)
    print("TOP 20 CONFIGURATIONS")
    print("=" * 120)
    print(f"{'Rank':>4} {'Score':>6} {'λB':>5} {'C0':>5} {'S̄':>5} {'sξ':>5} {'ΔS':>5} "
          f"{'Hump':>5} {'κ†':>5} {'Δmin':>8} {'Amp%':>6} "
          f"{'Hold':>5} {'HW':>6} {'Disc%':>7} {'pBid':>6} {'Fail':>4} {'Res':>7}")
    print("-" * 120)

    for i, r in enumerate(results[:20]):
        print(
            f"{i+1:>4} {r.score:>6.1f} "
            f"{r.lambda_B:>5.2f} {r.C0:>5.2f} {r.S_bar:>5.2f} {r.s_xi:>5.2f} {r.Delta_S:>5.2f} "
            f"{'YES' if r.hump_exists else 'NO':>5} "
            f"{r.hump_peak_kappa:>5.2f} {r.hump_peak_value:>8.5f} {r.hump_amplitude_pct:>6.1f} "
            f"{'YES' if r.hold_exists else 'NO':>5} {r.hold_width_at_050:>6.3f} "
            f"{r.disclosure_effect_pct:>7.1f} "
            f"{r.avg_bid_rate:>6.3f} "
            f"{r.n_failed:>4} {r.max_residual:>7.4f}"
        )

    # Also show configurations that have hump AND hold AND disclosure
    triple = [r for r in results if r.hump_exists and r.hold_exists and abs(r.disclosure_effect_pct) > 1.0]
    if triple:
        print(f"\n\n{'='*120}")
        print(f"TRIPLE WIN: Hump + Hold + Disclosure ({len(triple)} configs)")
        print("=" * 120)
        for i, r in enumerate(triple[:10]):
            print(
                f"{i+1:>4} {r.score:>6.1f} "
                f"λB={r.lambda_B:.2f} C0={r.C0:.2f} S̄={r.S_bar:.2f} sξ={r.s_xi:.2f} ΔS={r.Delta_S:.2f} "
                f"κ†={r.hump_peak_kappa:.2f} Δmin={r.hump_peak_value:.5f} Amp={r.hump_amplitude_pct:.1f}% "
                f"HW={r.hold_width_at_050:.3f} Disc={r.disclosure_effect_pct:.1f}% "
                f"pBid={r.avg_bid_rate:.3f}"
            )
    else:
        print("\n\nNo configurations achieved all three targets (hump + hold + disclosure).")
        # Show best hump + hold
        hh = [r for r in results if r.hump_exists and r.hold_exists]
        if hh:
            print(f"Best hump+hold ({len(hh)} configs):")
            for r in hh[:5]:
                print(f"  Score={r.score:.1f} λB={r.lambda_B:.2f} C0={r.C0:.2f} S̄={r.S_bar:.2f} sξ={r.s_xi:.2f}")

        # Show best hump + disclosure
        hd = [r for r in results if r.hump_exists and abs(r.disclosure_effect_pct) > 1.0]
        if hd:
            print(f"Best hump+disclosure ({len(hd)} configs):")
            for r in hd[:5]:
                print(f"  Score={r.score:.1f} λB={r.lambda_B:.2f} C0={r.C0:.2f} S̄={r.S_bar:.2f} sξ={r.s_xi:.2f}")

    # Print best overall configuration details
    if results:
        best = results[0]
        print(f"\n\n{'='*80}")
        print("BEST CONFIGURATION DETAILS")
        print(f"{'='*80}")
        print(f"  lambda_B = {best.lambda_B}")
        print(f"  C0       = {best.C0}")
        print(f"  S_bar    = {best.S_bar}")
        print(f"  s_xi     = {best.s_xi}")
        print(f"  Delta_S  = {best.Delta_S}")
        print(f"  ---")
        print(f"  Hump exists: {best.hump_exists}, peak at κ = {best.hump_peak_kappa:.3f}")
        print(f"  Δ^min peak = {best.hump_peak_value:.6f}, amplitude = {best.hump_amplitude_pct:.1f}%")
        print(f"  Hold exists: {best.hold_exists}, width at κ=0.50: {best.hold_width_at_050:.4f}")
        print(f"  Disclosure effect: {best.disclosure_effect_pct:.2f}%")
        print(f"  Max bid rate: {best.max_bid_rate:.4f}, avg bid rate: {best.avg_bid_rate:.4f}")
        print(f"  Max residual: {best.max_residual:.6f}, failures: {best.n_failed}")
        print(f"  Net deterrence: {best.net_deterrence}")
        print(f"  Score: {best.score:.1f}")


if __name__ == "__main__":
    main()
