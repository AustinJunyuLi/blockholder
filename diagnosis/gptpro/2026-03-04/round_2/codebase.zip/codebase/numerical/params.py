"""
Model parameters and type definitions for the Exit-Voice-Takeover model.

This is the foundational module — all other modules in the numerical package
import from here. It defines:

- Named tolerance constants used across the solver and equilibrium routines
- The ``Action`` enum encoding the blockholder's four action choices
- ``Cutoffs`` and ``MinorityGains`` named tuples for structured return values
- The ``ModelParams`` dataclass with baseline calibration and derived quantities
"""

from __future__ import annotations

import dataclasses
import enum
from dataclasses import dataclass
from typing import NamedTuple

import numpy as np

# ---------------------------------------------------------------------------
# Tolerance constants
# ---------------------------------------------------------------------------

TOL_PROB: float = 1e-10       # Near-zero probability threshold
TOL_CONVERGE: float = 1e-6    # Fixed-point convergence criterion
TOL_RESIDUAL: float = 5e-3    # Equilibrium quality gate
TOL_REGION: float = 1e-4      # Cutoff region collapse detection


# ---------------------------------------------------------------------------
# Action enum
# ---------------------------------------------------------------------------

class Action(enum.Enum):
    """Blockholder action choice (Definition 2 in the paper).

    EXIT   -- Sell stake  (q = -1, a = 0)
    HOLD   -- Passive hold (q = 0,  a = 0)
    QUIET  -- Quiet Voice: engage below disclosure threshold (q = 0,  a = 1)
    PUBLIC -- Public Voice: buy, engage, trigger disclosure  (q = +1, a = 1)
    """

    EXIT = "E"
    HOLD = "H"
    QUIET = "Q"
    PUBLIC = "P"


# ---------------------------------------------------------------------------
# Named tuples
# ---------------------------------------------------------------------------

class Cutoffs(NamedTuple):
    """Equilibrium signal cutoffs (Proposition 1).

    k1: Exit/Hold boundary -- signals below k1 trigger exit
    k0: Hold/Quiet Voice boundary -- signals above k0 trigger engagement
    kD: Quiet/Public Voice boundary -- signals above kD trigger disclosure

    Satisfies k1 <= k0 <= kD (weak ordering allows region collapse).
    """

    k1: float
    k0: float
    kD: float


class MinorityGains(NamedTuple):
    """Expected minority takeover gains decomposition.

    total: Total expected minority gains Delta^min
    base:  Base component m0 * Pr(bid)
    activism: Activism-driven component Delta^act
    """

    total: float
    base: float
    activism: float


# ---------------------------------------------------------------------------
# Model parameters
# ---------------------------------------------------------------------------

@dataclass
class ModelParams:
    """Parameters for the Exit-Voice-Takeover model.

    Notation follows the paper:

        mu, sigma_v     -- Prior: v ~ N(mu, sigma_v^2)              
        sigma_eps       -- Signal noise: s = v + eps                 
        kappa           -- Noise trading intensity                   
        C0, chi         -- Engagement cost: C(s) = C0*exp(-chi*z)   
        rho, Delta      -- Success probability and value improvement 
        m0, m1          -- Takeover premia without/with engagement   
        S_bar, K        -- Baseline synergy and bidding cost         
        Delta_S         -- Synergy improvement from activism         
        s_xi            -- Logistic synergy shock scale              
        lambda_B        -- Bidder arrival rate (scales bid prob.)    
        delta           -- Discount factor                           

    Default values correspond to the baseline calibration used throughout
    the paper (Table C.3).
    """

    # Fundamentals
    mu: float = 1.0                # Prior mean of v
    sigma_v: float = 0.50          # Std dev of v
    sigma_eps: float = 0.50        # Std dev of signal noise

    # Liquidity
    kappa: float = 0.50            # Noise trading intensity

    # Engagement
    C0: float = 0.25               # Base engagement cost
    chi: float = 0.50              # Cost sensitivity to signal
    rho: float = 0.90              # Engagement success probability
    Delta: float = 0.25            # Value improvement from engagement

    # Takeover
    m0: float = 0.10               # Base takeover premium
    m1: float = 0.30               # Premium with successful engagement
    S_bar: float = 1.10            # Baseline synergy
    Delta_S: float = 0.30          # Expected fundamental synergy improvement from activism
    K: float = 0.15                # Bidding cost
    s_xi: float = 0.15             # Logistic synergy shock scale
    lambda_B: float = 0.20         # Poisson bidder arrival rate

    # Discounting
    delta: float = 0.95            # Discount factor

    # -- Derived quantities ------------------------------------------------

    @property
    def sigma_s(self) -> float:
        """Signal standard deviation: sqrt(sigma_v^2 + sigma_eps^2)."""
        return float(np.sqrt(self.sigma_v**2 + self.sigma_eps**2))

    @property
    def beta(self) -> float:
        """Posterior weight on the signal in v_hat(s)."""
        return self.sigma_v**2 / (self.sigma_v**2 + self.sigma_eps**2)

    @property
    def m_tilde(self) -> float:
        """Expected takeover premium under engagement."""
        return self.m0 + self.rho * (self.m1 - self.m0)

    @property
    def Delta_tilde(self) -> float:
        """Expected value improvement under engagement."""
        return self.rho * self.Delta

    @property
    def net_deterrence_active(self) -> bool:
        """Verify Assumption (A5): Net Deterrence Condition.
        
        Requires: Delta_tilde + m_tilde - m0 > Delta_S
        """
        return (self.Delta_tilde + self.m_tilde - self.m0) > self.Delta_S

    # -- Convenience methods -----------------------------------------------

    def replace(self, **kwargs) -> ModelParams:
        """Return a copy with specified fields overridden."""
        return dataclasses.replace(self, **kwargs)

    @classmethod
    def baseline(cls) -> ModelParams:
        """Baseline calibration used in the paper."""
        return cls()
