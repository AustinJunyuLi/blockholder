"""
Data export for the Exit-Voice-Takeover model.

Extracts computation logic from figures.py and writes CSV files
for downstream R/ggplot2 visualization. No matplotlib dependency.

Usage:
    python -m numerical.export_data [--output-dir DIR]
"""

from __future__ import annotations

import csv
import os
from typing import Dict, List, Optional, Tuple

import numpy as np

from numerical.params import (
    Cutoffs,
    ModelParams,
    TOL_PROB,
    TOL_REGION,
    TOL_RESIDUAL,
)
from numerical.model import (
    bid_probability,
    compute_action_probabilities,
    compute_conditional_means,
    compute_equilibrium_prices,
    compute_minority_gains,
    compute_minority_gains_no_disclosure_given_strategy,
    compute_minority_gains_noisy_rumor,
    compute_posteriors,
    compute_posteriors_full_information,
    compute_posteriors_no_disclosure,
    compute_posteriors_noisy_rumor,
    compute_welfare,
    noise_probs,
    compute_E_v_given_XD,
)
from numerical.solver import (
    compute_series_over_kappa,
    solve_equilibrium,
    solve_valid,
)

def _write_csv(path: str, header: List[str], rows: List[List]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)

def _fmt(x: float, decimals: int = 10) -> str:
    if x is None or (isinstance(x, float) and (np.isnan(x) or not np.isfinite(x))):
        return "NA"
    return f"{x:.{decimals}f}"

def export_baseline_params(params: ModelParams, data_dir: str) -> None:
    rows = [
        ["mu", _fmt(params.mu)],
        ["sigma_v", _fmt(params.sigma_v)],
        ["sigma_eps", _fmt(params.sigma_eps)],
        ["sigma_s", _fmt(params.sigma_s)],
        ["kappa", _fmt(params.kappa)],
        ["C0", _fmt(params.C0)],
        ["chi", _fmt(params.chi)],
        ["rho", _fmt(params.rho)],
        ["Delta", _fmt(params.Delta)],
        ["m0", _fmt(params.m0)],
        ["m1", _fmt(params.m1)],
        ["m_tilde", _fmt(params.m_tilde)],
        ["S_bar", _fmt(params.S_bar)],
        ["Delta_S", _fmt(params.Delta_S)],
        ["K", _fmt(params.K)],
        ["s_xi", _fmt(params.s_xi)],
        ["lambda_B", _fmt(params.lambda_B)],
        ["delta", _fmt(params.delta)],
        ["beta", _fmt(params.beta)],
        ["Delta_tilde", _fmt(params.Delta_tilde)],
    ]
    _write_csv(os.path.join(data_dir, "baseline_params.csv"), ["param", "value"], rows)

def export_cutoff_structure(k1: float, k0: float, kD: float, params: ModelParams, data_dir: str) -> None:
    _write_csv(
        os.path.join(data_dir, "baseline_cutoffs.csv"),
        ["k1", "k0", "kD", "mu", "sigma_s"],
        [[_fmt(k1), _fmt(k0), _fmt(kD), _fmt(params.mu), _fmt(params.sigma_s)]],
    )
    x_min = params.mu - 3 * params.sigma_s
    x_max = max(params.mu + 4 * params.sigma_s, kD + 0.5 * params.sigma_s)
    has_hold = (k0 - k1) > TOL_REGION
    regions: List[List[str]] = [["Exit", _fmt(x_min), _fmt(k1)]]
    quiet_left = k0 if has_hold else k1
    if has_hold: regions.append(["Hold", _fmt(k1), _fmt(k0)])
    regions.append(["Quiet Voice", _fmt(quiet_left), _fmt(kD)])
    regions.append(["Public Voice", _fmt(kD), _fmt(x_max)])
    _write_csv(os.path.join(data_dir, "cutoff_regions.csv"), ["region", "xmin", "xmax"], regions)

def export_baseline_series(params: ModelParams, data_dir: str, n_points: int = 35) -> Dict[str, np.ndarray]:
    kappa_values = np.linspace(0.15, 0.85, n_points)
    series = compute_series_over_kappa(params, kappa_values, include_no_disclosure=False)
    rows = [[_fmt(float(series[k][i])) for k in ["kappa", "k1", "k0", "kD", "Delta_min", "base", "act"]] for i in range(len(kappa_values))]
    _write_csv(os.path.join(data_dir, "baseline_series.csv"), ["kappa", "k1", "k0", "kD", "Delta_min", "base", "act"], rows)
    return series

def export_prices(k1: float, k0: float, kD: float, params: ModelParams, data_dir: str) -> None:
    prices, prices_trade, E_v_dict = compute_equilibrium_prices(k1, k0, kD, params)
    omega_E, omega_H, omega_Q, omega_P = compute_action_probabilities(k1, k0, kD, params)
    posteriors = compute_posteriors(omega_E, omega_H, omega_Q, omega_P, params.kappa)
    p0, p1 = noise_probs(params.kappa)

    prob_XD: Dict[Tuple[int, int], float] = {}
    actions = [("E", -1, 0, omega_E), ("H", 0, 0, omega_H), ("Q", 0, 0, omega_Q), ("P", 1, 1, omega_P)]
    for _name, q, D, omega in actions:
        if omega < TOL_PROB: continue
        for z, pz in [(-1, p1), (0, p0), (1, p1)]:
            prob_XD[(q + z, D)] = prob_XD.get((q + z, D), 0.0) + float(omega) * float(pz)

    rows = []
    for X in [-2, -1, 0, 1]:
        on_path = prob_XD.get((X, 0), 0.0) > 1e-4
        P = prices.get((X, 0), float("nan"))
        P_tr = prices_trade.get(X, float("nan"))
        pi = posteriors.get((X, 0), 0.0)
        V_hat_XD = E_v_dict.get((X, 0), params.mu) + params.Delta_tilde * pi
        m_XD = params.m0 + (params.m_tilde - params.m0) * pi
        p_bid = params.lambda_B * bid_probability(V_hat_XD, m_XD, pi, params) if np.isfinite(P) else float("nan")
        rows.append([str(X), "0", _fmt(P), _fmt(P_tr), _fmt(pi), _fmt(p_bid), _fmt(m_XD), "TRUE" if on_path else "FALSE"])

    for X in [0, 1, 2]:
        on_path = prob_XD.get((X, 1), 0.0) > 1e-4
        P = prices.get((X, 1), float("nan"))
        P_tr = prices_trade.get(X, float("nan"))
        pi = 1.0
        V_hat_XD = E_v_dict.get((X, 1), params.mu) + params.Delta_tilde * pi
        m_XD = params.m_tilde
        p_bid = params.lambda_B * bid_probability(V_hat_XD, m_XD, pi, params) if np.isfinite(P) else float("nan")
        rows.append([str(X), "1", _fmt(P), _fmt(P_tr), _fmt(pi), _fmt(p_bid), _fmt(m_XD), "TRUE" if on_path else "FALSE"])

    _write_csv(os.path.join(data_dir, "prices.csv"), ["X", "D", "P_post", "P_trade", "pi", "p_bid", "m_XD", "on_path"], rows)

def export_disclosure_attenuation(base_params: ModelParams, k1_ref: float, k0_ref: float, kD_ref: float, data_dir: str, n_points: int = 35) -> None:
    kappa_values = np.linspace(0.15, 0.85, n_points)
    rows = []
    for kappa in kappa_values:
        params_k = base_params.replace(kappa=float(kappa))
        _, _, act_k = compute_minority_gains(k1_ref, k0_ref, kD_ref, params_k)
        _, _, act_nd_k = compute_minority_gains_no_disclosure_given_strategy(k1_ref, k0_ref, kD_ref, params_k)
        rows.append([_fmt(float(kappa)), _fmt(act_k), _fmt(act_nd_k)])
    _write_csv(os.path.join(data_dir, "disclosure_attenuation.csv"), ["kappa", "act_disclosure", "act_no_disclosure"], rows)

def _export_sensitivity(base_params, param_name, param_values, param_field, data_dir, csv_name, replace_fn=None):
    kappa_values = np.linspace(0.25, 0.85, 21)
    rows = []
    for pval in param_values:
        prev = None
        for kappa in kappa_values:
            try:
                p = replace_fn(base_params, float(kappa), pval) if replace_fn else base_params.replace(kappa=float(kappa), **{param_field: pval})
                cutoffs, res = solve_valid(p, prev)
                if cutoffs is None or not np.isfinite(res) or res > TOL_RESIDUAL:
                    rows.append([_fmt(float(kappa)), _fmt(pval), "NA"])
                    prev = None
                    continue
                prev = cutoffs
                total, _, _ = compute_minority_gains(cutoffs.k1, cutoffs.k0, cutoffs.kD, p)
                rows.append([_fmt(float(kappa)), _fmt(pval), _fmt(total)])
            except Exception:
                rows.append([_fmt(float(kappa)), _fmt(pval), "NA"])
    _write_csv(os.path.join(data_dir, csv_name), ["kappa", param_name, "Delta_min"], rows)

def export_sensitivity_C0(base_params: ModelParams, data_dir: str): _export_sensitivity(base_params, "C0", [0.06, 0.12, 0.21, 0.24], "C0", data_dir, "sensitivity_C0.csv")
def export_sensitivity_wedge(base_params: ModelParams, data_dir: str): _export_sensitivity(base_params, "wedge", [0.10, 0.20, 0.30], "m1", data_dir, "sensitivity_wedge.csv", replace_fn=lambda bp, k, w: bp.replace(kappa=k, m1=bp.m0 + w))
def export_sensitivity_rho(base_params: ModelParams, data_dir: str): _export_sensitivity(base_params, "rho", [0.5, 0.7, 0.9], "rho", data_dir, "sensitivity_rho.csv")
def export_sensitivity_s_xi(base_params: ModelParams, data_dir: str): _export_sensitivity(base_params, "s_xi", [0.10, 0.15, 0.25], "s_xi", data_dir, "sensitivity_s_xi.csv")
def export_sensitivity_delta(base_params: ModelParams, data_dir: str): _export_sensitivity(base_params, "delta", [0.85, 0.90, 0.95], "delta", data_dir, "sensitivity_delta.csv")

def export_noisy_rumor(base_params: ModelParams, data_dir: str) -> None:
    kappa_values = np.linspace(0.25, 0.85, 21)
    rumor_configs = [(0.50, 0.50, "Uninformative"), (0.75, 0.25, "Moderate"), (0.95, 0.05, "Precise")]
    rows = []
    for eta_1, eta_0, label in rumor_configs:
        prev = None
        for kappa in kappa_values:
            try:
                p = base_params.replace(kappa=float(kappa))
                cutoffs, res = solve_valid(p, prev)
                if cutoffs is None or not np.isfinite(res) or res > TOL_RESIDUAL:
                    rows.append([_fmt(float(kappa)), _fmt(eta_1), _fmt(eta_0), label, "NA"])
                    prev = None
                    continue
                prev = cutoffs
                gains = compute_minority_gains_noisy_rumor(cutoffs.k1, cutoffs.k0, cutoffs.kD, p, eta_1, eta_0)
                rows.append([_fmt(float(kappa)), _fmt(eta_1), _fmt(eta_0), label, _fmt(gains.total)])
            except Exception:
                rows.append([_fmt(float(kappa)), _fmt(eta_1), _fmt(eta_0), label, "NA"])
    _write_csv(os.path.join(data_dir, "noisy_rumor.csv"), ["kappa", "eta_1", "eta_0", "label", "Delta_min"], rows)

def export_welfare(base_params: ModelParams, data_dir: str) -> None:
    kappa_values = np.linspace(0.25, 0.85, 21)
    rows, prev = [], None
    for kappa in kappa_values:
        try:
            p = base_params.replace(kappa=float(kappa))
            cutoffs, res = solve_valid(p, prev)
            if cutoffs is None or not np.isfinite(res) or res > TOL_RESIDUAL:
                rows.append([_fmt(float(kappa)), "NA", "NA", "NA"])
                prev = None
                continue
            prev = cutoffs
            W_min, W_bid, _, W_tot = compute_welfare(cutoffs.k1, cutoffs.k0, cutoffs.kD, p)
            rows.append([_fmt(float(kappa)), _fmt(W_min), _fmt(W_bid), _fmt(W_tot)])
        except Exception:
            rows.append([_fmt(float(kappa)), "NA", "NA", "NA"])
    _write_csv(os.path.join(data_dir, "welfare.csv"), ["kappa", "W_min", "W_bid", "W_tot"], rows)


def write_baseline_table(k1: float, k0: float, kD: float, params: ModelParams, output_path: str) -> None:
    omega_E, omega_H, omega_Q, omega_P = compute_action_probabilities(k1, k0, kD, params)
    posteriors = compute_posteriors(omega_E, omega_H, omega_Q, omega_P, params.kappa)
    prices, _prices_trade, E_v_dict = compute_equilibrium_prices(k1, k0, kD, params)

    def row_for(X: int, D: int) -> str:
        P = prices.get((X, D), np.nan)
        pi = posteriors.get((X, D), 0.0)
        V_hat_XD = E_v_dict.get((X, D), params.mu) + params.Delta_tilde * pi
        m_XD = params.m0 + (params.m_tilde - params.m0) * pi
        p_bid = params.lambda_B * bid_probability(V_hat_XD, m_XD, pi, params) if np.isfinite(P) else np.nan
        return f"{D} & ${X}$ & {P:.2f} & {pi:.2f} & {p_bid:.2f} & {m_XD:.2f} \\\\"

    lines = ["\\begin{tabular}{llrrrr}", "\\toprule", "$D$ & Order flow $X$ & $P(X,D)$ & $\\pi(X,D)$ & $p(X,D)$ & $m(X,D)$ \\\\", "\\midrule"]
    for X in [-2, -1, 0, 1]: lines.append(row_for(X, 0))
    lines.append("\\midrule")
    for X in [0, 1, 2]: lines.append(row_for(X, 1))
    lines.extend(["\\bottomrule", "\\end{tabular}"])
    with open(output_path, "w", encoding="utf-8") as f: f.write("\n".join(lines) + "\n")

def write_disclosure_extension_table(k1, k0, kD, params, output_path, rho1=0.75, rho0=0.25):
    omega_E, omega_H, omega_Q, omega_P = compute_action_probabilities(k1, k0, kD, params)
    post_baseline = compute_posteriors(omega_E, omega_H, omega_Q, omega_P, params.kappa)
    post_nd = compute_posteriors_no_disclosure(omega_E, omega_H, omega_Q, omega_P, params.kappa)
    post_nr = compute_posteriors_noisy_rumor(omega_E, omega_H, omega_Q, omega_P, params.kappa, rho1, rho0)
    post_fi = compute_posteriors_full_information()
    fmt = lambda x: f"{x:.2f}"
    
    lines = ["\\begin{tabular}{lrrrr}", "\\toprule", "$X$ & $\\pi(X,0)$ & $\\pi_{\\textup{ND}}(X)$ & $\\pi_{\\textup{NR}}(X,0,R=0)$ & $\\pi_{\\textup{NR}}(X,0,R=1)$ \\\\", "\\midrule"]
    for X in [-1, 0, 1]:
        lines.append(f"${X}$ & {fmt(post_baseline.get((X, 0), 0.0))} & {fmt(post_nd.get(X, 0.0))} & {fmt(post_nr.get((X, 0, 0), 0.0))} & {fmt(post_nr.get((X, 0, 1), 0.0))} \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}", "\\vspace{0.6em}", "\\begin{tabular}{ll}", "\\toprule", "$(q,a)$ & $\\pi_{\\textup{FI}}$ \\\\", "\\midrule"])
    for key in [(-1, 0), (0, 0), (0, 1), (1, 1)]: lines.append(f"$({key[0]},{key[1]})$ & {fmt(post_fi.get(key, 0.0))} \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}"])
    with open(output_path, "w", encoding="utf-8") as f: f.write("\n".join(lines) + "\n")

def export_all(output_dir: str = "numerical_output") -> None:
    data_dir = os.path.join(output_dir, "data")
    os.makedirs(data_dir, exist_ok=True)
    params = ModelParams()
    print("Solving baseline equilibrium...")
    k1, k0, kD = solve_equilibrium(params)
    print(f"Equilibrium cutoffs: k1={k1:.3f}, k0={k0:.3f}, kD={kD:.3f}")
    print(f"Net deterrence holds: {params.net_deterrence_active}")
    
    export_baseline_params(params, data_dir)
    export_cutoff_structure(k1, k0, kD, params, data_dir)
    export_baseline_series(params, data_dir)
    export_prices(k1, k0, kD, params, data_dir)
    export_disclosure_attenuation(params, k1, k0, kD, data_dir)
    export_sensitivity_C0(params, data_dir)
    export_sensitivity_wedge(params, data_dir)
    export_sensitivity_rho(params, data_dir)
    export_sensitivity_s_xi(params, data_dir)
    export_sensitivity_delta(params, data_dir)
    export_noisy_rumor(params, data_dir)
    export_welfare(params, data_dir)

    write_baseline_table(k1, k0, kD, params, os.path.join(output_dir, "table_example.tex"))
    write_disclosure_extension_table(k1, k0, kD, params, os.path.join(output_dir, "table_disclosure_extensions.tex"))

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Export model data to CSV")
    parser.add_argument("--output-dir", default="numerical_output", help="Output directory")
    args = parser.parse_args()
    export_all(output_dir=args.output_dir)
