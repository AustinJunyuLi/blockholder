# Author Context

This is a theory paper in finance on liquidity, activist disclosure, and takeover premia.

The current draft uses a discrete order-flow model with:
- activist choice among exit / hold / quiet voice / public voice,
- stake-triggered disclosure,
- Bayesian inference from order flow,
- bidder entry conditional on public signals.

The author is no longer committed to that architecture.

The author wants the **best possible model**, even if it requires a radical redesign, provided it remains in the same domain.

The main economic object the author wants to preserve is a **nonlinear, ideally hump-shaped relation between liquidity and expected minority takeover premia**.

The author is explicitly open to:
- continuous-time trading,
- stochastic calculus,
- filtering,
- singular or impulse control,
- optimal stopping,
- dynamic liquidity or search frictions,
- and other advanced techniques,

if those techniques genuinely improve the economics and the paper.

One motivation for rethinking the current architecture is that a standard Kyle-style setup seemed unable to cleanly handle a blockholder who simultaneously:
- trades on information,
- chooses whether to intervene,
- may cross disclosure thresholds,
- and affects takeover outcomes.

The question is whether that concern is real or whether a better continuous-time architecture can solve it.
